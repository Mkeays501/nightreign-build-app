"""Build a signed APK directly with the official Android SDK build tools.
The same project also imports into Android Studio / Gradle.
"""
import pathlib,os,subprocess,json,secrets,zipfile,sys,hashlib,shutil,tempfile,xml.etree.ElementTree as ET
ROOT=pathlib.Path(__file__).resolve().parents[1]
SDK=pathlib.Path(os.environ.get('ANDROID_SDK_ROOT',str(ROOT/'toolchain/sdk')))
VERSION=json.loads((ROOT/'app-version.json').read_text())
BUILD=ROOT/'build/manual';BUILD.mkdir(parents=True,exist_ok=True)
TOOLS=SDK/'build-tools/35.0.0';PLATFORM=SDK/'platforms/android-35/android.jar'
PRIVATE=ROOT/'signing-private';PRIVATE.mkdir(mode=0o700,exist_ok=True)
keyfile=PRIVATE/'nightreign-release.p12';settings=PRIVATE/'signing.json'
if not settings.exists():
 settings.write_text(json.dumps({'storePassword':secrets.token_urlsafe(32),'keyAlias':'nightreign','storeType':'PKCS12'},indent=2));os.chmod(settings,0o600)
config=json.loads(settings.read_text());env=os.environ.copy();env['NIGHTREIGN_STORE_PASS']=config['storePassword']
def run(cmd):subprocess.run([str(x) for x in cmd],check=True,env=env)
if not keyfile.exists():
 run(['keytool','-genkeypair','-keystore',keyfile,'-storetype','PKCS12','-storepass:env','NIGHTREIGN_STORE_PASS','-keypass:env','NIGHTREIGN_STORE_PASS','-alias','nightreign','-keyalg','RSA','-keysize','3072','-sigalg','SHA256withRSA','-validity','10000','-dname','CN=Nightreign Build Lab, OU=Independent fan project'])
 os.chmod(keyfile,0o600)
manifest=ET.parse(ROOT/'app/src/main/AndroidManifest.xml');android='{http://schemas.android.com/apk/res/android}';manifest.getroot().set('package','com.mkeays.nightreign');manifest.getroot().set(android+'versionCode',str(VERSION['versionCode']));manifest.getroot().set(android+'versionName',VERSION['versionName']);manifest.getroot().insert(0,ET.Element('uses-sdk',{android+'minSdkVersion':'26',android+'targetSdkVersion':'35'}));ET.register_namespace('android',android[1:-1]);manifest.write(BUILD/'AndroidManifest.xml',encoding='utf-8',xml_declaration=True)
run([TOOLS/'aapt2','compile','--dir',ROOT/'app/src/main/res','-o',BUILD/'resources.zip'])
run([TOOLS/'aapt2','link','--manifest',BUILD/'AndroidManifest.xml','-I',PLATFORM,'--java',BUILD/'generated','-A',ROOT/'app/src/main/assets','-R',BUILD/'resources.zip','-o',BUILD/'base.apk','--auto-add-overlay'])
classes=BUILD/'classes';classes.mkdir(exist_ok=True)
sources=list((ROOT/'app/src/main/java').rglob('*.java'))+list((BUILD/'generated').rglob('*.java'))
run(['java','com.sun.tools.javac.Main','-source','8','-target','8','-encoding','UTF-8','-bootclasspath',str(PLATFORM)+os.pathsep+str(TOOLS/'core-lambda-stubs.jar'),'-d',classes,*sources])
jar=BUILD/'classes.jar'
with zipfile.ZipFile(jar,'w',zipfile.ZIP_DEFLATED) as z:
 for path in classes.rglob('*.class'):z.write(path,str(path.relative_to(classes)))
dex=BUILD/'dex';dex.mkdir(exist_ok=True)
run(['java','-cp',TOOLS/'lib/d8.jar','com.android.tools.r8.D8','--release','--min-api','26','--lib',PLATFORM,'--output',dex,jar])
unsigned=BUILD/'unsigned.apk';shutil.copyfile(BUILD/'base.apk',unsigned)
with zipfile.ZipFile(unsigned,'a',zipfile.ZIP_DEFLATED) as z:
 for path in dex.glob('*.dex'):z.write(path,path.name)
run([TOOLS/'zipalign','-P','16','-f','4',unsigned,BUILD/'aligned.apk'])
output=ROOT/'dist';output.mkdir(exist_ok=True);apk=output/('Nightreign-Build-Lab-'+VERSION['versionName']+'.apk')
signed=pathlib.Path(tempfile.mkdtemp(prefix='nightreign-apk-'))/'signed.apk'
run([TOOLS/'apksigner','sign','--ks',keyfile,'--ks-type','PKCS12','--ks-key-alias','nightreign','--ks-pass','env:NIGHTREIGN_STORE_PASS','--key-pass','env:NIGHTREIGN_STORE_PASS','--v4-signing-enabled','false','--out',signed,BUILD/'aligned.apk'])
run([TOOLS/'apksigner','verify','--verbose','--print-certs',signed])
run([TOOLS/'aapt','dump','badging',signed])
temporary=apk.with_suffix('.apk.new')
with open(temporary,'wb') as stream:stream.write(signed.read_bytes());stream.flush();os.fsync(stream.fileno())
os.replace(temporary,apk);shutil.rmtree(signed.parent)
receipt={'file':apk.name,'bytes':apk.stat().st_size,'sha256':hashlib.sha256(apk.read_bytes()).hexdigest(),'applicationId':'com.mkeays.nightreign','versionCode':VERSION['versionCode'],'versionName':VERSION['versionName'],'minSdk':26,'targetSdk':35,'internetPermission':False,'sourceWebsiteCommit':'fdcdb420572d63ec92d177e7194c6491396608f7'}
(output/'build-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
