from pathlib import Path
import zipfile,json,subprocess,hashlib
r=Path(__file__).resolve().parents[1];d=r/'dist';receiptPath=r/'build/final-delivery-path.txt';apk=Path(receiptPath.read_text()) if receiptPath.exists() else d/('Nightreign-Build-Lab-'+json.loads((r/'app-version.json').read_text())['versionName']+'.apk')
with zipfile.ZipFile(apk) as z:
 names=z.namelist();assert 'classes.dex' in names;assert z.read('classes.dex').startswith(b'dex\n');assert z.read('assets/index.html')==(r/'app/src/main/assets/index.html').read_bytes();assert not any('.p12' in n or 'signing.json' in n for n in names)
perms=subprocess.check_output([str(r/'toolchain/sdk/build-tools/35.0.0/aapt'),'dump','permissions',str(apk)],text=True);assert 'uses-permission' not in perms
receipt=json.loads((d/'build-receipt.json').read_text());receipt['file']=apk.name;receipt['bytes']=apk.stat().st_size;receipt['sha256']=hashlib.sha256(apk.read_bytes()).hexdigest();receipt['checks']={'plannerAndAdapterTests':44,'nativePolicyAssertions':14,'signatureV2':True,'signatureV3':True,'bundledAssetHashMatches':True,'noRuntimePermissions':True,'deviceLaunchTested':False};(d/'build-receipt.json').write_text(json.dumps(receipt,indent=2))
with zipfile.ZipFile(d/'Nightreign-Android-Source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['app','gradle','tools','tests','web/src','web/tests','research']:
  for p in (r/name).rglob('*'):
   if p.is_file():z.write(p,str(p.relative_to(r)))
 for name in ['README.md','settings.gradle','build.gradle','gradle.properties','gradlew','gradlew.bat','.gitignore','app-version.json','GRADLE-WRAPPER-LICENSE.txt','web/build.py','web/README.md','web/THIRD_PARTY_NOTICES.txt','dist/build-receipt.json']:z.write(r/name,name)
with zipfile.ZipFile(d/'Nightreign-Signing-Backup-PRIVATE.zip','w',zipfile.ZIP_DEFLATED) as z:
 z.write(r/'signing-private/nightreign-release.p12','signing-private/nightreign-release.p12');z.write(r/'signing-private/signing.json','signing-private/signing.json')
 z.writestr('KEEP-PRIVATE.txt','This private signing key is needed to update the installed release app. Never upload this archive, the .p12 file, or signing.json to a public repository. The key password is stored in signing.json under storePassword. The key alias is nightreign. To reuse the alternative Python builder, restore the signing-private folder beside app/ and tools/. Keep a separate secure copy. Losing this key means future apps cannot update the existing installation.\n')
with zipfile.ZipFile(d/'Nightreign-Android-Source.zip') as z:assert not any('signing-private' in n or n.endswith('.p12') for n in z.namelist())
print(json.dumps({'apkBytes':apk.stat().st_size,'sha256':receipt['sha256'],'files':[p.name for p in d.iterdir() if p.suffix in ['.apk','.zip']]}))
