"""Bundle the existing planner; apply only Android-specific integration hooks."""
import pathlib,re,subprocess,sys,json,base64,urllib.request
ROOT=pathlib.Path(__file__).resolve().parents[1]
subprocess.run([sys.executable,str(ROOT/'web/build.py')],check=True)
html=(ROOT/'web/dist/index.html').read_text()
# Font files are shipped as data URLs, so the installed app has no network dependency.
fontdir=ROOT/'app/src/main/assets/fonts';fontdir.mkdir(exist_ok=True)
fonts=[('DM Sans','dmsans','DMSans[opsz,wght].ttf'),('Cormorant Garamond','cormorantgaramond','CormorantGaramond[wght].ttf')]
fontcss=''
for family,folder,name in fonts:
 target=fontdir/name
 if not target.exists():
  url='https://raw.githubusercontent.com/google/fonts/main/ofl/'+folder+'/'+urllib.parse.quote(name)
  target.write_bytes(urllib.request.urlopen(url,timeout=30).read())
  (fontdir/(folder+'-OFL.txt')).write_bytes(urllib.request.urlopen('https://raw.githubusercontent.com/google/fonts/main/ofl/'+folder+'/OFL.txt',timeout=30).read())
 encoded=base64.b64encode(target.read_bytes()).decode()
 fontcss+='@font-face{font-family:"'+family+'";font-style:normal;font-weight:100 900;font-display:swap;src:url(data:font/ttf;base64,'+encoded+') format("truetype");}'
html=re.sub(r"@import url\('https://fonts\.googleapis\.com/[^']*'\);",lambda _:fontcss,html,count=1)
def swap(old,new):
 global html
 if html.count(old)!=1:raise RuntimeError('Planner integration point changed: '+old[:60])
 html=html.replace(old,new,1)
swap("function exportBuild(){", "function exportBuild(){if(window.NightreignNative){window.NightreignNative.saveBuild(JSON.stringify(state,null,2),state.name.replace(/[^a-z0-9-]/gi,'_').slice(0,50)+'.json');return;}")
swap("const url=location.origin+location.pathname+'#b='+content;showModal", "const url=location.origin+location.pathname+'#b='+content;if(window.NightreignNative){window.NightreignNative.shareBuild(url);return;}showModal")
swap("case 'copy-share':try{", "case 'copy-share':if(window.NightreignNative){window.NightreignNative.copyBuildLink($('#share-url').value);break;}try{")
html=html.replace('Builds are saved in this browser.','Builds are saved inside this app on this device.')
swap('LOCAL SAVES · SHAREABLE BUILDS · NO LOGIN','ANDROID APP · OFFLINE PLANNER · LOCAL SAVES')
back="""<script>window.handleAndroidBack=function(){const modal=document.querySelector('#modal');if(modal&&modal.open){modal.close();return true;}const drawer=document.querySelector('#drawer');if(drawer&&!drawer.hidden){document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true}));return true;}return false;};</script>"""
html=html.replace('</body>',back+'</body>')
csp="<meta http-equiv=\"Content-Security-Policy\" content=\"default-src 'none';script-src 'unsafe-inline';style-src 'unsafe-inline';img-src data:;font-src data:;connect-src 'none';frame-src 'none';object-src 'none';base-uri 'none';form-action 'none'\">"
html=html.replace('<head>','<head>'+csp,1)
(ROOT/'app/src/main/assets/index.html').write_text(html)
for f in fontdir.glob('*.ttf'):f.unlink() # Font bytes are embedded exactly once.
(ROOT/'app/src/main/assets/THIRD_PARTY_NOTICES.txt').write_text((ROOT/'web/THIRD_PARTY_NOTICES.txt').read_text()+'\n\nBundled fonts: DM Sans and Cormorant Garamond, SIL Open Font License1.1. Full licenses are included in assets/fonts/.\n')
print(json.dumps({'assetBytes':len(html.encode()),'characters':10,'weapons':391,'nativeShare':True,'nativeExport':True,'networkPermission':False}))
