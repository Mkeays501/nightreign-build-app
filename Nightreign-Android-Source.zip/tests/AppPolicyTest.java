import com.mkeays.nightreign.AppPolicy;
public final class AppPolicyTest {
    public static void main(String[] args) {
        String base=AppPolicy.WEBSITE;
        assert AppPolicy.isInternalAnchor(base+"#planner");
        assert AppPolicy.isBuildLink(base+"#b=eyJhIjoxfQ");
        assert !AppPolicy.isBuildLink(base+"#planner");
        assert !AppPolicy.isBuildLink("https://mkeays501.github.io.evil.example/nightreign-build-lab/#b=abc");
        assert !AppPolicy.isBuildLink("https://mkeays501.github.io@evil.example/nightreign-build-lab/#b=abc");
        assert !AppPolicy.isBuildLink(base+"?tracker=x#b=abc");
        assert !AppPolicy.isBuildLink(base+"#b=<script>");
        assert !AppPolicy.isBuildLink(base+"#b="+new String(new char[24001]).replace('\0','a'));
        assert !AppPolicy.isInternalAnchor("file:///sdcard/private.json");
        assert !AppPolicy.isExternalWebLink("javascript:alert(1)");
        assert !AppPolicy.isExternalWebLink("intent://app/settings");
        assert AppPolicy.isExternalWebLink("https://almanauts.com/nightreign/");
        assert !AppPolicy.safeFilename("../../private/build").contains("/");
        assert AppPolicy.safeFilename("my build").endsWith(".json");
        System.out.println("14 native URL and document-policy assertions passed.");
    }
}
