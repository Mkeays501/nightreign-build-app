# Nightreign Build Lab — Android

An installable Android application containing the complete Nightreign planner: ten Nightfarers, relic and vessel planning, 391 armaments, parameter-based attack rating, and weapon comparisons. The existing HTML/CSS/JavaScript interface runs inside a native Android WebView, bundled in the APK. This is a hybrid Android app, with an Android launcher icon, private on-device saves, native sharing and Android document pickers.

## Install

Download `Nightreign-Build-Lab-1.0.2.apk` directly on your Android phone and open the download. Android may ask you to allow installation from the browser or file manager you used. After installation, open **Nightreign Build Lab** from your app drawer. Requires Android 8.0 or newer and a current Android System WebView. No account or network access is needed to use the planner.

This APK is for direct installation, not a Google Play listing. It is release-signed and is not debuggable. The Android version bundles the website snapshot from commit `fdcdb420572d63ec92d177e7194c6491396608f7` (26 October 2026). Game-data boundaries and calculation limitations remain visible inside the planner.

## Builds and links

Builds save in this app's own storage. Website and app storage are separate: export a build JSON from the website and import it in the app to transfer it. **Share build** opens the Android share sheet with a normal public website build link. **Import or export build** uses Android's document picker for JSON. Sources open in the default browser when you tap them. App and data updates require a new APK.

The app requests no Android permissions, including no internet permission. All artwork, data and fonts are bundled. JSON files are accessed only through the document picker. Uninstalling the app removes its private builds; export any builds you want to keep first.

## Open and build in Android Studio

Open this project directory in Android Studio, let Gradle sync, then choose **Build > Build App Bundle(s) / APK(s) > Build APK(s)** for a development APK. The pinned toolchain is Android Gradle Plugin 8.9.3, Gradle 8.11.1, JDK17, SDK35 and Build Tools35.0.0. No third-party runtime dependencies are required.

From a terminal with Android SDK35 and JDK17 installed:

```sh
./gradlew assembleDebug
```

Development APKs use a separate `.debug` application ID, so they do not replace the release app. For updates to the release app, use the same private signing key. The signing backup is supplied separately and must never be committed to GitHub or included in an APK.

For a Gradle release build, set `NIGHTREIGN_KEYSTORE` to the private `.p12` file, `NIGHTREIGN_STORE_PASSWORD` and `NIGHTREIGN_KEY_PASSWORD` to the backup password, and `NIGHTREIGN_KEY_ALIAS` to `nightreign`, then run `./gradlew assembleRelease`. Increment `app-version.json` for app updates. Keep credentials in environment variables or Android Studio's private signing configuration.

The alternative `python tools/build_apk.py` builds with the official SDK's AAPT2, D8, zipalign and apksigner directly. It expects `ANDROID_SDK_ROOT` to point to an SDK with Platform35 and Build Tools35.0.0. If a private signing backup is present under `signing-private/`, it reuses that key. Otherwise it generates a new local signing identity: that new identity cannot update an existing installation signed by a different key.

## Rebuild web assets

`web/src/` contains the original planner sources. Run `python tools/prepare_assets.py` after editing them. This rebuilds the web bundle, embeds the two OFL fonts and adds the Android sharing/export/Back hooks. The checked-in `app/src/main/assets/index.html` is already complete, so initial app builds do not need this command or any network font download.

## Validation

```sh
node --test web/tests/*.test.mjs tests/*.test.mjs
javac -d build/policy-tests app/src/main/java/com/mkeays/nightreign/AppPolicy.java tests/AppPolicyTest.java
java -ea -cp build/policy-tests AppPolicyTest
```

Validation covers 44 planner/adapter tests (including all5,759 weapon variants across ten characters), 14 native URL/document-policy assertions, Android compilation, launcher/manifest verification and APK v2/v3 signing verification. Physical-device or emulator launch testing was not available in the build environment; the first installation should be tested on your phone, particularly import/export and external link opening.

## Credits

Independent fan project, not affiliated with or endorsed by FromSoftware or Bandai Namco. Original artwork and game data retain their existing credits. `app/src/main/assets/THIRD_PARTY_NOTICES.txt` includes the original notices. Bundled DM Sans and Cormorant Garamond fonts use SIL Open Font License1.1; full licenses are in `app/src/main/assets/fonts/`. Gradle Wrapper is Apache2.0; its notice is included in this project.

Version1.0.1 fixes false rejection of owned relic combinations: snapshot group, roll-order, type-eligibility and paired-drawback metadata are advisory warnings, not blockers. Valid mapped effects still calculate. Structural limits and colour/expedition slot checks remain enforced.


Version 1.0.2 audits numerical relic magnitudes against versioned parameters, adds Raider’s conditional damage/stamina bonus, and deduplicates identical fixed/random aliases of two non-stacking effects. The supplied regulation has binder version 10110019; it is not substituted for the later 10350000 comparison snapshot. Audit evidence and remaining uncertainties are recorded in research/relic-audit-2026-11-09.json. Matching a numeric payload does not verify all native activation, refresh, stacking or drop-generation behavior. Seven existing modifier entries retain visible community-model labels. No claim of complete game simulation is made.
