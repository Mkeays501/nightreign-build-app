package com.mkeays.nightreign;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** An offline Android application containing the complete Nightreign planner. */
public final class MainActivity extends Activity {
    private static final int PICK_BUILD = 1001, SAVE_BUILD = 1002;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private String pendingBuild;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        if (state != null) pendingBuild = state.getString("pendingBuild");
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(16,23,24));
        root.setOnApplyWindowInsetsListener((view,insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                view.setPadding(bars.left,bars.top,bars.right,bars.bottom);
            } else {
                view.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        setContentView(root);
        try {
            webView = new WebView(this);
            webView.setBackgroundColor(Color.rgb(16,23,24));
            webView.setId(View.generateViewId());
            WebSettings settings = webView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setAllowFileAccess(false);
            settings.setAllowContentAccess(true); // Only documents explicitly chosen in Android's file picker.
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
            settings.setBlockNetworkLoads(true);
            settings.setSupportMultipleWindows(true);
            settings.setJavaScriptCanOpenWindowsAutomatically(false);
            settings.setMediaPlaybackRequiresUserGesture(true);
            webView.addJavascriptInterface(new NativeBridge(),"NightreignNative");
            webView.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request) {
                    String url=request.getUrl().toString();
                    if (request.isForMainFrame() && AppPolicy.isInternalAnchor(url)) return false;
                    if (request.isForMainFrame()) openExternal(url);
                    return true;
                }
                @Override public boolean shouldOverrideUrlLoading(WebView view,String url) {
                    if (AppPolicy.isInternalAnchor(url)) return false;
                    openExternal(url);return true;
                }
            });
            webView.setWebChromeClient(new WebChromeClient() {
                @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params) {
                    if (fileCallback!=null) fileCallback.onReceiveValue(null);
                    fileCallback=callback;
                    Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    intent.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/json","text/plain","application/octet-stream"});
                    try { startActivityForResult(intent,PICK_BUILD); }
                    catch (ActivityNotFoundException error) { callback.onReceiveValue(null);fileCallback=null;notice("A file picker is unavailable."); }
                    return true;
                }
                @Override public boolean onCreateWindow(WebView view,boolean dialog,boolean userGesture,Message result) {
                    if (!userGesture) return false;
                    WebView popup=new WebView(MainActivity.this);
                    popup.getSettings().setBlockNetworkLoads(true);
                    popup.setWebViewClient(new WebViewClient() {
                        @Override public boolean shouldOverrideUrlLoading(WebView window,WebResourceRequest request) { openExternal(request.getUrl().toString());window.destroy();return true; }
                        @Override public boolean shouldOverrideUrlLoading(WebView window,String url) { openExternal(url);window.destroy();return true; }
                    });
                    ((WebView.WebViewTransport) result.obj).setWebView(popup);
                    result.sendToTarget();return true;
                }
            });
            root.addView(webView,new FrameLayout.LayoutParams(-1,-1));
            String html;
            try (InputStream stream=getAssets().open("index.html")) { html=new String(readFully(stream),StandardCharsets.UTF_8); }
            webView.loadDataWithBaseURL(AppPolicy.WEBSITE,html,"text/html",null,AppPolicy.WEBSITE);
            if (Build.VERSION.SDK_INT >= 33) getOnBackInvokedDispatcher().registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,this::handleBack);
        } catch (Exception error) {
            TextView fallback=new TextView(this);
            fallback.setText("Nightreign Build Lab could not start. Update Android System WebView in Google Play, then reopen the app.");
            fallback.setTextColor(Color.WHITE);fallback.setPadding(32,48,32,32);root.removeAllViews();root.addView(fallback);
        }
    }
    private static byte[] readFully(InputStream stream) throws java.io.IOException {
        ByteArrayOutputStream output=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int n;
        while ((n=stream.read(buffer))!=-1) output.write(buffer,0,n);
        return output.toByteArray();
    }
    private void notice(String message) { runOnUiThread(() -> Toast.makeText(this,message,Toast.LENGTH_SHORT).show()); }
    private void openExternal(String value) {
        if (!AppPolicy.isExternalWebLink(value)) { notice("This link type is not supported.");return; }
        try { startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(value))); }
        catch (ActivityNotFoundException ignored) { notice("A browser is unavailable."); }
    }
    private void handleBack() {
        if (webView==null) { finish();return; }
        webView.evaluateJavascript("window.handleAndroidBack ? window.handleAndroidBack() : false",handled -> {
            if ("true".equals(handled)) return;
            if (webView.canGoBack()) webView.goBack();else finish();
        });
    }
    @Override public void onBackPressed() { handleBack(); }
    @Override protected void onSaveInstanceState(Bundle state) { super.onSaveInstanceState(state);state.putString("pendingBuild",pendingBuild); }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if (request==PICK_BUILD && fileCallback!=null) {
            Uri uri=result==RESULT_OK&&data!=null?data.getData():null;
            fileCallback.onReceiveValue(uri==null?null:new Uri[]{uri});fileCallback=null;
        } else if (request==SAVE_BUILD) {
            if (result==RESULT_OK && data!=null && data.getData()!=null && pendingBuild!=null) {
                try (OutputStream stream=getContentResolver().openOutputStream(data.getData(),"wt")) {
                    if (stream==null) throw new java.io.IOException("No document stream");
                    stream.write(pendingBuild.getBytes(StandardCharsets.UTF_8));notice("Build JSON saved.");
                } catch (Exception ignored) { notice("The build could not be saved. Try another folder."); }
            }
            pendingBuild=null;
        }
    }
    @Override protected void onPause() { super.onPause();if (webView!=null) webView.onPause(); }
    @Override protected void onResume() { super.onResume();if (webView!=null) webView.onResume(); }
    @Override protected void onDestroy() {
        if (fileCallback!=null) { fileCallback.onReceiveValue(null);fileCallback=null; }
        if (webView!=null) { webView.removeJavascriptInterface("NightreignNative");webView.destroy(); }
        super.onDestroy();
    }
    public final class NativeBridge {
        @JavascriptInterface public void shareBuild(String value) {
            if (!AppPolicy.isBuildLink(value)) { notice("The build link is invalid or too long.");return; }
            runOnUiThread(() -> {
                Intent share=new Intent(Intent.ACTION_SEND);share.setType("text/plain");
                share.putExtra(Intent.EXTRA_SUBJECT,"Nightreign Build Lab");share.putExtra(Intent.EXTRA_TEXT,value);
                try { startActivity(Intent.createChooser(share,"Share Nightreign build")); }
                catch (ActivityNotFoundException ignored) { notice("No sharing app is available."); }
            });
        }
        @JavascriptInterface public void copyBuildLink(String value) {
            if (!AppPolicy.isBuildLink(value)) return;
            runOnUiThread(() -> { ClipboardManager manager=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);manager.setPrimaryClip(ClipData.newPlainText("Nightreign build",value));notice("Build link copied."); });
        }
        @JavascriptInterface public void saveBuild(String value,String filename) {
            if (value==null || value.getBytes(StandardCharsets.UTF_8).length>AppPolicy.MAX_BUILD_BYTES) { notice("Build JSON must be under 100 KB.");return; }
            try { new JSONObject(value); } catch (Exception ignored) { notice("Build JSON is invalid.");return; }
            runOnUiThread(() -> {
                pendingBuild=value;
                Intent save=new Intent(Intent.ACTION_CREATE_DOCUMENT);save.addCategory(Intent.CATEGORY_OPENABLE);
                save.setType("application/json");save.putExtra(Intent.EXTRA_TITLE,AppPolicy.safeFilename(filename));
                try { startActivityForResult(save,SAVE_BUILD); }
                catch (ActivityNotFoundException ignored) { pendingBuild=null;notice("A file picker is unavailable."); }
            });
        }
    }
}
