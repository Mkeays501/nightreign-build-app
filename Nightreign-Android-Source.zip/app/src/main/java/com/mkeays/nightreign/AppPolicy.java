package com.mkeays.nightreign;
import java.net.URI;
/** Platform-free policy shared by the native bridge and JVM verification. */
public final class AppPolicy {
    public static final String WEBSITE = "https://mkeays501.github.io/nightreign-build-lab/";
    public static final int MAX_BUILD_BYTES = 100000;
    private AppPolicy() {}
    public static boolean isInternalAnchor(String value) {
        try {
            URI uri = new URI(value);
            return "https".equals(uri.getScheme()) && "mkeays501.github.io".equals(uri.getHost())
                && "/nightreign-build-lab/".equals(uri.getPath()) && uri.getPort() == -1
                && uri.getRawUserInfo() == null && uri.getRawQuery() == null && uri.getRawFragment() != null;
        } catch (Exception ignored) { return false; }
    }
    public static boolean isBuildLink(String value) {
        if (value == null || value.length() > 25000 || !isInternalAnchor(value)) return false;
        String hash = value.substring(value.indexOf('#') + 1);
        return hash.startsWith("b=") && hash.substring(2).matches("[A-Za-z0-9_-]{1,24000}");
    }
    public static boolean isExternalWebLink(String value) {
        try { URI uri = new URI(value);return ("https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) && uri.getHost()!=null && uri.getRawUserInfo()==null; }
        catch (Exception ignored) { return false; }
    }
    public static String safeFilename(String value) {
        if (value == null) return "Nightreign-build.json";
        String name = value.replaceAll("[^a-zA-Z0-9._-]", "_");
        if (name.length() > 70) name = name.substring(0,70);
        return name.endsWith(".json") ? name : name + ".json";
    }
}
